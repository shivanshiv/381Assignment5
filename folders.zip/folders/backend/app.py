from flask import Flask, request, jsonify
from flask_cors import CORS
import json
import random

app = Flask(__name__)
CORS(app)

# Load JSON data
with open('data/courses.json') as f:
    courses = json.load(f)
with open('data/testimonials.json') as f:
    testimonials = json.load(f)

# In-memory students storage
students = []

@app.route('/register', methods=['POST'])
def register():
    data = request.json
    required_fields = ['username', 'password', 'email']
    if not all(field in data for field in required_fields):
        return jsonify({'error': 'Missing required fields'}), 400

    if any(s['username'] == data['username'] for s in students):
        return jsonify({'error': 'Username already exists'}), 400
    
    student = {
        'id': len(students) + 1,
        'username': data['username'],
        'password': data['password'],
        'email': data['email'],
        'enrolled_courses': []
    }
    students.append(student)
    return jsonify({'message': 'Registration successful', 'student_id': student['id']}), 201

@app.route('/login', methods=['POST'])
def login():
    data = request.json
    if not data or 'username' not in data or 'password' not in data:
        return jsonify({'error': 'Missing username or password'}), 400

    student = next((s for s in students if s['username'] == data['username'] and s['password'] == data['password']), None)
    if student:
        return jsonify({'message': 'Login successful', 'student_id': student['id']}), 200
    return jsonify({'error': 'Invalid credentials'}), 401

@app.route('/testimonials', methods=['GET'])
def get_testimonials():
    return jsonify(random.sample(testimonials, min(2, len(testimonials))))

@app.route('/enroll/<int:student_id>', methods=['POST'])
def enroll_course(student_id):
    student = next((s for s in students if s['id'] == student_id), None)
    if not student:
        return jsonify({'error': 'Student not found'}), 404
    
    course = request.json
    if course['id'] in student['enrolled_courses']:
        return jsonify({'error': 'Already enrolled in this course'}), 400
    
    student['enrolled_courses'].append(course['id'])
    return jsonify({'message': 'Enrollment successful'})

@app.route('/drop/<int:student_id>', methods=['DELETE'])
def drop_course(student_id):
    student = next((s for s in students if s['id'] == student_id), None)
    if not student:
        return jsonify({'error': 'Student not found'}), 404
    
    course = request.json
    if course['id'] not in student['enrolled_courses']:
        return jsonify({'error': 'Not enrolled in this course'}), 400
    
    student['enrolled_courses'].remove(course['id'])
    return jsonify({'message': 'Course dropped successfully'})

@app.route('/courses', methods=['GET'])
def get_courses():
    return jsonify(courses)

@app.route('/student_courses/<int:student_id>', methods=['GET'])
def get_student_courses(student_id):
    student = next((s for s in students if s['id'] == student_id), None)
    if not student:
        return jsonify({'error': 'Student not found'}), 404
    
    enrolled_courses = [c for c in courses if c['id'] in student['enrolled_courses']]
    return jsonify(enrolled_courses)

if __name__ == '__main__':
    app.run(debug=True)
