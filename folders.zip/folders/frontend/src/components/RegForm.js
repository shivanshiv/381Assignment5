import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import "./signup.css";

function RegForm() {
  const [form, setForm] = useState({ username: '', password: '', confirmPassword: '', email: '' });
  const [errors, setErrors] = useState([]);
  const navigate = useNavigate();

  const handleChange = e => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const validate = () => {
    const { username, password, confirmPassword, email } = form;
    const newErrors = [];

    if (username.length < 3 || username.length > 20) {
      newErrors.push("Username must be between 3 and 20 characters long.");
    }
    if (!/^[A-Za-z]/.test(username)) {
      newErrors.push("Username must start with a letter.");
    }
    if (!/^[A-Za-z0-9_-]+$/.test(username)) {
      newErrors.push("Username can only contain letters, numbers, hyphens, and underscores.");
    }

    if (password.length < 8) {
      newErrors.push("Password must be at least 8 characters long.");
    }
    if (!/[A-Z]/.test(password)) newErrors.push("Password must contain an uppercase letter.");
    if (!/[a-z]/.test(password)) newErrors.push("Password must contain a lowercase letter.");
    if (!/[0-9]/.test(password)) newErrors.push("Password must contain a number.");
    if (!/[!@#$%^&*()\-=+\[\]{}|;:'\",.<>?/`~]/.test(password)) {
      newErrors.push("Password must include a special character.");
    }
    if (/\s/.test(password)) {
      newErrors.push("Password cannot contain spaces.");
    }

    if (password !== confirmPassword) {
      newErrors.push("Passwords do not match.");
    }

    if (!/^[^\s@]+@[^\s@]+\.(com|net|io)$/.test(email)) {
      newErrors.push("Email must be a valid format with .com, .net, or .io domain.");
    }

    return newErrors;
  };

  const handleSubmit = async e => {
    e.preventDefault();
    const validationErrors = validate();

    if (validationErrors.length > 0) {
      setErrors(validationErrors);
      return;
    }

    try {
      const response = await fetch('http://localhost:5000/api/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form)
      });

      if (response.ok) {
        navigate('/login');
      } else {
        const { message } = await response.json();
        setErrors([message || "Signup failed."]);
      }
    } catch (err) {
      setErrors(["Network error occurred."]);
    }
  };

  return (
    <main>
      <h2>Sign Up</h2>
      <div className="form-container">
        {errors.length > 0 && (
          <div className="message-box error">
            {errors.map((err, idx) => <div key={idx}>{err}</div>)}
          </div>
        )}
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label>Username:</label>
            <input
              type="text"
              id="username"
              name="username"
              value={form.username}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-group">
            <label>Password:</label>
            <input
              type="password"
              id="password"
              name="password"
              value={form.password}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-group">
            <label>Confirm Password:</label>
            <input
              type="password"
              id="confirmPassword"
              name="confirmPassword"
              value={form.confirmPassword}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-group">
            <label>Email:</label>
            <input
              type="email"
              id="email"
              name="email"
              value={form.email}
              onChange={handleChange}
              required
            />
          </div>

          <button type="submit" className="button-submit">Sign Up</button>
          <p><a href="/login">Already have an account? Login here</a></p>
        </form>
      </div>
    </main>
  );
}


export default RegForm;

