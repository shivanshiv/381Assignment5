import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from './AuthContext';
import DisplayStatus from './DisplayStatus';
import Header from './Header';
import Footer from './Footer';

const LoginFormContent = () => {
  const [credentials, setCredentials] = useState({ username: '', password: '' });
  const [status, setStatus] = useState({ type: '', message: '' });
  const [users, setUsers] = useState([]);
  const navigate = useNavigate();
  const { setAuth } = useAuth();


  useEffect(() => {
    fetch('https://jsonplaceholder.typicode.com/users')
      .then(response => response.json())
      .then(data => setUsers(data));
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!credentials.username || !credentials.password) {
      setStatus({ type: 'error', message: 'All fields are required' });
      return;
    }

    if (credentials.password.length < 8) {
      setStatus({ type: 'error', message: 'Password must be at least 8 characters' });
      return;
    }

    const user = users.find(u => 
      u.username === credentials.username || u.email === credentials.username
    );

    if (user) {
      setAuth({ username: user.username, email: user.email });
      setStatus({ type: 'success', message: 'Login successful!' });
      setTimeout(() => navigate('/courses'), 2000);
    } else {
      setStatus({ type: 'error', message: 'Invalid credentials' });
    }
  };

  return (
    <form onSubmit={handleSubmit} className="form-group form-container">
      <input
        type="text"
        placeholder="Username or Email"
        value={credentials.username}
        onChange={(e) => setCredentials({...credentials, username: e.target.value})}
      />
      <input
        type="password"
        placeholder="Password"
        value={credentials.password}
        onChange={(e) => setCredentials({...credentials, password: e.target.value})}
      />
      <button type="submit" className="button-submit">Login</button>
      <DisplayStatus type={status.type} message={status.message} />
    </form>
  );
};

const LoginForm = () => {
  return (
    <div>
      <Header />
      <main className="login-main">
        <div>
          <br></br>
          <h2>LMS Login</h2>
          <br></br>
        </div>
        <LoginFormContent />
        <br></br>
        <a href="./login">Forgot Password?</a>
        <a href='./signup'>Don't have an account? Sign up</a>
      </main>
      <Footer />
    </div>
  );
};

export default LoginForm;
