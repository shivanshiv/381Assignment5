import React from "react";
import { Link } from "react-router-dom";
import "./styles.css";

const Header = () => {
  return (
    <div className="header-container">
      <header className="header">
        <img src="/images/logo.jpg" alt="LMS Logo" className="logo" />
        <h1>LMS - Learning Management System</h1>
      </header>
      
      <nav className="nav">
        <Link to="/" className="nav-link">Home</Link>
        <Link to="/courses" className="nav-link">Courses</Link>
        <Link to="/login" className="nav-link">Login</Link>
        <Link to="/signup" className="nav-link">Sign Up</Link>
      </nav>
    </div>
  );
};

export default Header;
