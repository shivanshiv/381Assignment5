import React, { useState, useEffect } from 'react';
import courses from '../data/courses';
import Header from '../components/Header';
import Footer from '../components/Footer';
import './pages.css';


const CourseItem = ({ course, onEnroll }) => {
    const [showDescription, setShowDescription] = useState(false);

    return (
        <div className="course-item"
            onMouseEnter={() => setShowDescription(true)}
            onMouseLeave={() => setShowDescription(false)}>
            <img src={course.image} alt={course.name} />
            <h3>{course.name}</h3>
            <p>{course.instructor}</p>
            {showDescription && <p>{course.description}</p>}
            <button className="button-submit" onClick={() => onEnroll(course)}>Enroll Now</button>
        </div>
    );
};


const EnrolledCourse = ({ course, enrollment, onDrop }) => {
    return (
        <div className="enrolled-course">
            <h2>{course.name}</h2>
            <p>Credit Hours: {enrollment.creditHours}</p>
            <button className="button-drop" onClick={() => onDrop(course.id)}>Drop Course</button>
        </div>
    );
};

const EnrollmentList = ({ enrollments, onDrop }) => {
    useEffect(() => {
        localStorage.setItem('enrollments', JSON.stringify(enrollments));
    }, [enrollments]);

    const totalCreditHours = Object.values(enrollments).reduce(
        (total, enrollment) => total + enrollment.creditHours,
        0
    );

    const totalEnrollmentCount = Object.values(enrollments).reduce(
        (total, enrollment) => total + enrollment.count,
        0
    );

    return (
        <div>
            <h1>Enrolled Courses</h1>
            {Object.entries(enrollments).map(([courseId, enrollment]) => (
                <EnrolledCourse
                    key={courseId}
                    course={courses.find(c => c.id === parseInt(courseId))}
                    enrollment={enrollment}
                    onDrop={onDrop}
                />
            ))}
            <div>
                Total Credit Hours: {totalCreditHours}
                <p>Total Enrollment Count: {totalEnrollmentCount}</p>
            </div>
        </div>
    );
};

const CourseCatalog = ({ onEnroll }) => {
    return (
        <div>
            {courses.map(course => (
                <CourseItem 
                    key={course.id} 
                    course={course} 
                    onEnroll={onEnroll} 
                />
            ))}
        </div>
    );
};

const CoursesPage = () => {
    const [enrollments, setEnrollments] = useState({});
    useEffect(() => {
        const savedEnrollments = localStorage.getItem('enrollments');
        if (savedEnrollments) {
            setEnrollments(JSON.parse(savedEnrollments));
        }
    }, []);

    useEffect(() => {
        if (Object.keys(enrollments).length > 0) {
            localStorage.setItem('enrollments', JSON.stringify(enrollments));
        }
    }, [enrollments]);

    const handleEnroll = (course) => {
        setEnrollments(prev => {
            const newEnrollments = { ...prev };
            if (newEnrollments[course.id]) {
                newEnrollments[course.id].count++;
            } else {
                newEnrollments[course.id] = { count: 1, creditHours: 3 }; 
            }
            return newEnrollments;
        });
    };

    const handleDrop = (courseId) => {
        setEnrollments(prev => {
            const updated = { ...prev };
            if (updated[courseId].count > 1) {
                updated[courseId].count--; 
            } else {
                delete updated[courseId]; 
            }
            return updated;
        });
    };

    return (
        <div>
            <Header />
            <main className="main">
                <div>
                    <CourseCatalog onEnroll={handleEnroll} />
                    <EnrollmentList 
                        enrollments={enrollments}
                        onDrop={handleDrop}
                    />
                </div>
            </main>
            <Footer />
        </div>
    );
};

export default CoursesPage;
