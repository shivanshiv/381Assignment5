import React from 'react';
import { useAuth } from './AuthContext';
import DisplayStatus from './DisplayStatus';

const AuthMessage = () => {
  const { auth, error } = useAuth();
  
  return (
    <div className="auth-message">
      {auth?.username && (
        <DisplayStatus 
          type="success" 
          message={`Welcome back, ${auth.username}!`} 
        />
      )}
      {error && (
        <DisplayStatus 
          type="error" 
          message={error} 
        />
      )}
    </div>
  );
};

export default AuthMessage;
