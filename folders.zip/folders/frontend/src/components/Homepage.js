import React, { useState, useEffect } from "react";
import Header from "./Header";
import Footer from "./Footer";
import courses from "../data/courses";
import testimonials from "../data/testimonials";
import "./pages.css";

const MainSection = () => {
  const [featuredCourses, setFeaturedCourses] = useState([]);
  const [randomTestimonials, setRandomTestimonials] = useState([]);

  useEffect(() => {
    setFeaturedCourses(courses.sort(() => 0.5 - Math.random()).slice(0, 3));
    setRandomTestimonials(testimonials.sort(() => 0.5 - Math.random()).slice(0, 2));
  }, []);

  return (
    <main className="main">
      <section id="about">
        <h2>About LMS</h2>
        <p>
          The Learning Management System (LMS) helps students and instructors manage courses, quizzes, and track
          performance efficiently.
        </p>
      </section>

      <section>
        <h3>Featured Courses</h3>
        <ul>
          {featuredCourses.map((course, index) => (
            <li key={index}>{course.name}</li>
          ))}
        </ul>
      </section>

      <section>
        <h3>Student Testimonials</h3>
        {randomTestimonials.map((testimonial, index) => (
          <div key={index}>
            <p>"{testimonial.review}"</p>
            <p>- {testimonial.studentName}</p>
            <p>{"★".repeat(testimonial.rating) + "☆".repeat(5 - testimonial.rating)}</p>
          </div>
        ))}
      </section>
    </main>
  );
};

const Homepage = () => {
  return (
    <div>
      <Header />
      <MainSection />
      <Footer />
    </div>
  );
};

export default Homepage;