import React from 'react';
import './App.css';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import SignupPage from './components/SignupPage';
import Homepage from './components/Homepage';
import CoursePages from './components/CoursePages';
import LoginForm from './components/LoginForm';
import AuthMessage from './components/AuthMessage';
import { AuthProvider } from './components/AuthContext';


function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <div className="App">
          <Routes>
            <Route path="/" element={<Homepage />} />
            <Route path="/courses" element={<CoursePages />} />
            <Route path="/login" element={<LoginForm />} />
            <Route path="/dashboard" element={<AuthMessage />} />
            <Route path="/signup" element={<SignupPage />} />
          </Routes>
        </div>
      </BrowserRouter>
    </AuthProvider>
  );
}


export default App;
