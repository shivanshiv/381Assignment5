const courses = [
    {
        id: 1,
        name: "Web Development",
        instructor: "Dr. John Smith",
        description: "Master HTML, CSS, and JavaScript.",
        duration: "8 weeks",
        image: "images/course1.jpg"
    },
    {
        id: 2,
        name: "Computer Organization",
        instructor: "Dr. Steve Norman",
        description: "Learn about RISC-V assembly language.",
        duration: "4 weeks",
        image: "images/course1.jpg"
    },
    {
        id: 3,
        name: "Object Oriented Principles",
        instructor: "Dr. Ann Barcomb",
        description: "Learn about RISC-V assembly language.",
        duration: "12 weeks",
        image: "images/course1.jpg"
    },
    {
        id: 4,
        name: "Data Structures and Algorithms",
        instructor: "Dr. Mann Khedr",
        description: "Learn about data structures and algorithms in python.",
        duration: "16 weeks",
        image: "images/course1.jpg"
    },
    {
        id: 5,
        name: "Anatomy and Physiology",
        instructor: "Dr. Eli Kinney-Lang",
        description: "Master anatomical systems and functions.",
        duration: "14 weeks",
        image: "images/course1.jpg"
    },
    {
        id: 6,
        name: "Digital Circuits",
        instructor: "Dr. Dennis Onen",
        description: "Learn about boolean algebra, karnaugh maps, digital design.",
        duration: "10 weeks",
        image: "images/course1.jpg"
    },
    {
        id: 6,
        name: "Differential Calculus",
        instructor: "Dr. Mohammed Aiffa",
        description: "Learn about advanced calculus, differential equations.",
        duration: "20 weeks",
        image: "images/course1.jpg"
    },
    {
        id: 7,
        name: "Introduction to Biomedical Engineering",
        instructor: "Dr. Emma Farago",
        description: "Prerequisite for other biomedical courses.",
        duration: "12 weeks",
        image: "images/course1.jpg"
    },
    {
        id: 8,
        name: "Technical Communication",
        instructor: "Dr. Andrea Hanslip",
        description: "Examines dimensions of workplace settings.",
        duration: "9 weeks",
        image: "images/course1.jpg"
    },
    {
        id: 9,
        name: "Electricity and Magnetism",
        instructor: "Dr. Sean Stotyn",
        description: "Provides introduction to engineering physics.",
        duration: "10 weeks",
        image: "images/course1.jpg"
    },
    {
        id: 10,
        name: "Fundamentals of Fluids",
        instructor: "Dr. Kazi Sumon",
        description: "Provides introduction to fluids and their behaviour.",
        duration: "20 weeks",
        image: "images/course1.jpg"
    }
];
export default courses;
