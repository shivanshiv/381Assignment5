const testimonials = [
    {
        studentName: "Alice Johnson",
        courseName: "Web Development",
        review: "Excellent course structure!",
        rating: 5
    },
    {
        studentName: "Hannah Brennan",
        courseName: "Data Structures and Algorithms",
        review: "Bad structure but teacher is an easy marker.",
        rating: 3
    },
    {
        studentName: "Chester Kelly",
        courseName: "Fundamentals of Fluids",
        review: "Terrible course and terrible teacher.",
        rating: 1
    },
    {
        studentName: "Freddy Marks",
        courseName: "Electricity and Magnetism",
        review: "Easy course if you're good at physics!",
        rating: 4
    }
];
export default testimonials;
