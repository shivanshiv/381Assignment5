import React, { useState, useEffect } from "react";
import Header from "./Header";
import Footer from "./Footer";
import API_BASE_URL from "../config";
import "./pages.css";

const MainSection = () => {
  const [featuredCourses, setFeaturedCourses] = useState([]);
  const [testimonials, setTestimonials] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    // Fetch courses for featured section
    const fetchCourses = async () => {
      try {
        const response = await fetch(`${API_BASE_URL}/courses`);
        if (response.ok) {
          const data = await response.json();
          // Pick 3 random courses for featured section
          setFeaturedCourses(data.sort(() => 0.5 - Math.random()).slice(0, 3));
        }
      } catch (err) {
        console.error("Error fetching courses:", err);
      }
    };
    
    // Fetch testimonials from backend
    const fetchTestimonials = async () => {
      try {
        const response = await fetch(`${API_BASE_URL}/testimonials`);
        
        if (!response.ok) {
          throw new Error(`Failed to fetch testimonials: ${response.status}`);
        }
        
        const data = await response.json();
        setTestimonials(data);
      } catch (err) {
        console.error("Error fetching testimonials:", err);
        setError("Failed to load testimonials. Please try again later.");
      } finally {
        setLoading(false);
      }
    };

    fetchCourses();
    fetchTestimonials();
  }, []);

  return (
    <main className="main">
      <section id="about">
        <h2>About LMS</h2>
        <p>
          The Learning Management System (LMS) helps students and instructors manage courses, quizzes, and track
          performance efficiently.
        </p>
      </section>

      <section>
        <h3>Featured Courses</h3>
        <ul>
          {featuredCourses.map((course, index) => (
            <li key={index}>{course.name}</li>
          ))}
        </ul>
      </section>

      <section>
        <h3>Student Testimonials</h3>
        {loading ? (
          <p>Loading testimonials...</p>
        ) : error ? (
          <p>{error}</p>
        ) : testimonials.length > 0 ? (
          testimonials.map((testimonial, index) => (
            <div key={index}>
              <p>"{testimonial.review}"</p>
              <p>- {testimonial.studentName}</p>
              <p>{"★".repeat(testimonial.rating) + "☆".repeat(5 - testimonial.rating)}</p>
            </div>
          ))
        ) : (
          <p>No testimonials available.</p>
        )}
      </section>
    </main>
  );
};

const Homepage = () => {
  return (
    <div>
      <Header />
      <MainSection />
      <Footer />
    </div>
  );
};

export default Homepage;