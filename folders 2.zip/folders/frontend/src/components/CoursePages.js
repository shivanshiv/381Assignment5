import React, { useState, useEffect } from 'react';
import Header from './Header';
import Footer from './Footer';
import { useAuth } from './AuthContext';
import { useNavigate } from 'react-router-dom';
import DisplayStatus from './DisplayStatus';
import API_BASE_URL from '../config';
import './pages.css';

const CourseItem = ({ course, onEnroll }) => {
    const [showDescription, setShowDescription] = useState(false);

    return (
        <div className="course-item"
            onMouseEnter={() => setShowDescription(true)}
            onMouseLeave={() => setShowDescription(false)}>
            <img src={course.image} alt={course.name} />
            <h3>{course.name}</h3>
            <p>{course.instructor}</p>
            {showDescription && <p>{course.description}</p>}
            <button className="button-submit" onClick={() => onEnroll(course)}>Enroll Now</button>
        </div>
    );
};

const EnrolledCourse = ({ course, enrollment, onDrop }) => {
    return (
        <div className="enrolled-course">
            <h2>{course.name}</h2>
            <p>Credit Hours: {enrollment.creditHours}</p>
            <button className="button-drop" onClick={() => onDrop(course.id)}>Drop Course</button>
        </div>
    );
};

const CoursesPage = () => {
    const [allCourses, setAllCourses] = useState([]);
    const [enrolledCourses, setEnrolledCourses] = useState([]);
    const [enrollments, setEnrollments] = useState({});
    const [loading, setLoading] = useState(true);
    const [statusMessage, setStatusMessage] = useState({ type: '', message: '' });
    const { auth } = useAuth();
    const navigate = useNavigate();

    // Redirect if not authenticated
    useEffect(() => {
        if (!auth) {
            navigate('/login');
        }
    }, [auth, navigate]);

    // Fetch all courses and enrolled courses from API
    useEffect(() => {
        if (!auth) return;

        const fetchData = async () => {
            setLoading(true);
            try {
                // Fetch all courses
                const coursesResponse = await fetch(`${API_BASE_URL}/courses`);
                if (!coursesResponse.ok) {
                    throw new Error(`Failed to fetch courses: ${coursesResponse.status}`);
                }
                const coursesData = await coursesResponse.json();
                setAllCourses(coursesData);

                // Fetch student's enrolled courses
                const enrolledResponse = await fetch(`${API_BASE_URL}/student_courses/${auth.id}`);
                if (enrolledResponse.ok) {
                    const enrolledData = await enrolledResponse.json();
                    setEnrolledCourses(enrolledData);
                    
                    // Create enrollments object
                    const newEnrollments = {};
                    enrolledData.forEach(course => {
                        newEnrollments[course.id] = { count: 1, creditHours: 3 };
                    });
                    setEnrollments(newEnrollments);
                }
            } catch (err) {
                console.error("Error fetching data:", err);
                setStatusMessage({ 
                    type: 'error', 
                    message: 'Failed to load courses. Please try again later.' 
                });
            } finally {
                setLoading(false);
            }
        };

        fetchData();
    }, [auth]);

    const handleEnroll = async (course) => {
        if (!auth) {
            navigate('/login');
            return;
        }

        try {
            const response = await fetch(`${API_BASE_URL}/enroll/${auth.id}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id: course.id })
            });

            const data = await response.json();
            
            if (response.ok) {
                setEnrolledCourses(prev => [...prev, course]);
                setEnrollments(prev => ({
                    ...prev,
                    [course.id]: { count: 1, creditHours: 3 }
                }));
                setStatusMessage({ type: 'success', message: 'Successfully enrolled in course!' });
            } else {
                setStatusMessage({ type: 'error', message: data.error || 'Failed to enroll in course' });
            }
        } catch (err) {
            console.error("Enrollment error:", err);
            setStatusMessage({ type: 'error', message: 'Network error occurred. Is the backend server running?' });
        }
    };

    const handleDrop = async (courseId) => {
        try {
            const response = await fetch(`${API_BASE_URL}/drop/${auth.id}`, {
                method: 'DELETE',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id: courseId })
            });

            const data = await response.json();
            
            if (response.ok) {
                setEnrolledCourses(prev => prev.filter(course => course.id !== courseId));
                setEnrollments(prev => {
                    const updated = { ...prev };
                    delete updated[courseId];
                    return updated;
                });
                setStatusMessage({ type: 'success', message: 'Course dropped successfully' });
            } else {
                setStatusMessage({ type: 'error', message: data.error || 'Failed to drop course' });
            }
        } catch (err) {
            console.error("Drop course error:", err);
            setStatusMessage({ type: 'error', message: 'Network error occurred. Is the backend server running?' });
        }
    };

    if (loading) {
        return (
            <div>
                <Header />
                <main className="main"><p>Loading courses...</p></main>
                <Footer />
            </div>
        );
    }

    return (
        <div className="course-view-page">
            <Header />
            <main className="main">
                <h2>Available Courses</h2>
                <DisplayStatus type={statusMessage.type} message={statusMessage.message} />
                
                <div className="course-catalog">
                    {allCourses.map(course => (
                        <CourseItem 
                            key={course.id} 
                            course={course} 
                            onEnroll={handleEnroll} 
                        />
                    ))}
                </div>
                
                <h2>Enrolled Courses</h2>
                <div className="enrolled-courses">
                    {enrolledCourses.length > 0 ? (
                        enrolledCourses.map(course => (
                            <EnrolledCourse
                                key={course.id}
                                course={course}
                                enrollment={enrollments[course.id] || { count: 1, creditHours: 3 }}
                                onDrop={() => handleDrop(course.id)}
                            />
                        ))
                    ) : (
                        <p>You are not enrolled in any courses.</p>
                    )}
                </div>
                
                <div className="enrollment-summary">
                    <p>Total Credit Hours: {
                        Object.values(enrollments).reduce(
                            (total, enrollment) => total + enrollment.creditHours, 0
                        )
                    }</p>
                    <p>Total Enrollment Count: {
                        Object.values(enrollments).reduce(
                            (total, enrollment) => total + enrollment.count, 0
                        )
                    }</p>
                </div>
            </main>
            <Footer />
        </div>
    );
};

export default CoursesPage;
