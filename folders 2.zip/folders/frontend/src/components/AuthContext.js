import React, { createContext, useContext, useState, useEffect } from 'react';
import API_BASE_URL from '../config';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [auth, setAuth] = useState(() => {
    // Load auth state from localStorage on initial render
    const savedAuth = localStorage.getItem('auth');
    return savedAuth ? JSON.parse(savedAuth) : null;
  });
  const [error, setError] = useState(null);

  // Save auth state to localStorage when it changes
  useEffect(() => {
    if (auth) {
      localStorage.setItem('auth', JSON.stringify(auth));
    } else {
      localStorage.removeItem('auth');
    }
  }, [auth]);

  const login = async (username, password) => {
    try {
      const response = await fetch(`${API_BASE_URL}/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
      });
      
      const data = await response.json();
      
      if (response.ok) {
        setAuth({ username, id: data.student_id });
        setError(null);
        return true;
      } else {
        setError(data.error || 'Invalid credentials');
        return false;
      }
    } catch (err) {
      setError('Login failed: Network error');
      return false;
    }
  };

  const logout = () => {
    setAuth(null);
    setError(null);
    localStorage.removeItem('auth');
  };

  return (
    <AuthContext.Provider value={{ auth, error, login, logout, setAuth }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
