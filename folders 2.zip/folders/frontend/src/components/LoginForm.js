import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from './AuthContext';
import DisplayStatus from './DisplayStatus';
import Header from './Header';
import Footer from './Footer';
import API_BASE_URL from '../config';

const LoginFormContent = () => {
  const [credentials, setCredentials] = useState({ username: '', password: '' });
  const [status, setStatus] = useState({ type: '', message: '' });
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const { setAuth } = useAuth();

  const testConnection = async () => {
    try {
      setStatus({ type: 'info', message: 'Testing API connection...' });
      const response = await fetch(`${API_BASE_URL}/`, { 
        method: 'GET',
        headers: { 'Content-Type': 'application/json' }
      });
      if (response.ok) {
        const data = await response.json();
        setStatus({ type: 'success', message: 'API connection successful: ' + data.message });
        return true;
      } else {
        setStatus({ type: 'error', message: `API returned error: ${response.status}` });
        return false;
      }
    } catch (err) {
      setStatus({ 
        type: 'error', 
        message: `Backend connection failed: ${err.message}. Make sure the backend server is running.` 
      });
      return false;
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    
    if (!credentials.username || !credentials.password) {
      setStatus({ type: 'error', message: 'All fields are required' });
      setLoading(false);
      return;
    }

    if (credentials.password.length < 8) {
      setStatus({ type: 'error', message: 'Password must be at least 8 characters' });
      setLoading(false);
      return;
    }

    try {
      // For demonstration, you can use the test account credentials:
      // username: test
      // password: Test1234!
      
      console.log('Sending login request...');
      const response = await fetch(`${API_BASE_URL}/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(credentials)
      });

      console.log('Login response status:', response.status);
      const data = await response.json();
      console.log('Login response data:', data);
      
      if (response.ok) {
        setAuth({ username: credentials.username, id: data.student_id });
        setStatus({ type: 'success', message: 'Login successful!' });
        setTimeout(() => navigate('/courses'), 2000);
      } else {
        setStatus({ type: 'error', message: data.error || 'Invalid credentials' });
      }
    } catch (err) {
      console.error('Login error:', err);
      setStatus({ 
        type: 'error', 
        message: `Network error occurred: ${err.message}. Is the backend server running?` 
      });
      
      // Offer to test connection
      const connectionTest = window.confirm('Would you like to test the connection to the backend?');
      if (connectionTest) {
        await testConnection();
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="form-group form-container">
      <input
        type="text"
        placeholder="Username or Email"
        value={credentials.username}
        onChange={(e) => setCredentials({...credentials, username: e.target.value})}
      />
      <input
        type="password"
        placeholder="Password"
        value={credentials.password}
        onChange={(e) => setCredentials({...credentials, password: e.target.value})}
      />
      <button type="submit" className="button-submit" disabled={loading}>
        {loading ? 'Logging in...' : 'Login'}
      </button>
      <DisplayStatus type={status.type} message={status.message} />
      <div style={{ marginTop: '10px', fontSize: '0.8em', color: '#666' }}>
        <p>For testing: Use username "test" and password "Test1234!"</p>
        <button 
          type="button" 
          onClick={testConnection} 
          style={{ fontSize: '0.9em', padding: '5px', marginTop: '5px' }}>
          Test API Connection
        </button>
      </div>
    </form>
  );
};

const LoginForm = () => {
  return (
    <div>
      <Header />
      <main className="login-main">
        <div>
          <br></br>
          <h2>LMS Login</h2>
          <br></br>
        </div>
        <LoginFormContent />
        <br></br>
        <a href="./login">Forgot Password?</a>
        <a href='./signup'>Don't have an account? Sign up</a>
      </main>
      <Footer />
    </div>
  );
};

export default LoginForm;
