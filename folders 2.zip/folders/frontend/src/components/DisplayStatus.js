import React from 'react';

const DisplayStatus = ({ type, message }) => {
  if (!message) return null;
  
  const styles = {
    success: {
      backgroundColor: '#d4edda',
      color: '#155724',
      border: '1px solid #c3e6cb',
      padding: '10px 20px',
      borderRadius: '4px',
      margin: '10px 0'
    },
    error: {
      backgroundColor: '#f8d7da',
      color: '#721c24',
      border: '1px solid #f5c6cb',
      padding: '10px 20px',
      borderRadius: '4px',
      margin: '10px 0'
    }
  };
  
  return (
    <div style={styles[type]}>
      {message}
    </div>
  );
};

export default DisplayStatus;
