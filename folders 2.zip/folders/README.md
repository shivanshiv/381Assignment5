Run backend:
cd backend
python app.py

Then run frontend:
cd frontend
npm install
npm start